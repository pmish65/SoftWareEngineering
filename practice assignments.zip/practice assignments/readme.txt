Note : all of these assignemnts are to be done with Spring MVC & Hibernate(JPA)
Usage of spring boot is preferred.

Online banking is a complete case study. As the lab exam objective , only a part of it will be expected, not the entire one.

Regarding J2EE lab exam

We will be only supplying a business scenario or a page flow diagram. You can use either only spring mvc with hibernate(i.e without spring boot) , with full dao implementations 
Or you can choose spring boot with Entity manager. So this kind of technology selection is up to you.

But you can't solve it using servlets or jsp n javabeans with jdbc.

Prepare 1 type  of technology stack well. Practice on E-R demos.
There won't be anything on RESTful service .